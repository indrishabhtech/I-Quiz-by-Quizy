# I-Quiz by Quizy
 A Quiz app made with javascript for helping students to prepare for competative exams
